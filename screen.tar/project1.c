#include <stdio.h>
#include "screen.h"
#include <unistd.h>

	int main(void){
		printf("Press any key to continue \n");
		getchar();

		for(int i = 0; i < 20; i++){
		clearscreen();
		setfgcolor(RED);
		gotoXY(20-i,i*2);
		printf("HELLO\n");
		setfgcolor(GREEN);
		for(int j = 0; j < 4; j++){
			gotoXY(i+1, i*2+j+1);
			printf("%s\n", BAR);
			gotoXY(i+2, i*2+j+1);
			printf("%s\n", BAR);
		}
		usleep(500000);
	}

	for(int i = 0; i < 20; i++){
		clearscreen();
		setfgcolor(RED);
		gotoXY(i,i*2+40);
		printf("HELLO\n");
		setfgcolor(GREEN);
		for(int j = 0; j < 4; j++){
			gotoXY(20-i+1, i*2+40+j+1);
			printf("%s\n", BAR);
			gotoXY(20-i+2, i*2+40+j+1);
			printf("%s\n", BAR);
		}
		usleep(500000);
	}
	getchar();
	clearscreen();
}
